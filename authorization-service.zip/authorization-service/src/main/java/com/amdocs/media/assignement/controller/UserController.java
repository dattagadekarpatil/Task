package com.amdocs.media.assignement.controller;

import java.util.List;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.amdocs.media.assignement.config.JwtTokenUtil;
import com.amdocs.media.assignement.entity.JwtResponse;
import com.amdocs.media.assignement.entity.User;
import com.amdocs.media.assignement.entity.UserProfileKafkaMessgae;
import com.amdocs.media.assignement.entity.UserProfileUpdate;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/v1")
@CrossOrigin("*")
public class UserController {

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private UserDetailsService jwtInMemoryUserDetailsService;

	@Autowired
	private RestTemplate restTemplate;

	@Value("${zuul.application.name}")
	private String zuulApplicationName;

	@Value("${profile.application.name}")
	private String profileApplicationName;

	@Value("${kafka.producer.request.topic.name}")
	private String requestTopicName;

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	private static final String OPERATION_DELETE = "deleteProfile";

	private static final String OPERATION_UPDATE = "updateProfile";
	
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	private final ObjectMapper objectMapper = new ObjectMapper();

	@Autowired
	private DiscoveryClient discoveryClient;

	@Autowired
	PasswordEncoder encoder;

	@PostMapping(value = "/login", consumes = "application/json")
	public ResponseEntity<?> userLogin(@RequestBody User user) throws Exception {
		logger.info("********userLogin()invoked " + user);
		Objects.requireNonNull(user.getUsername());
		Objects.requireNonNull(user.getPassword());
		Authentication authentication = authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
		SecurityContextHolder.getContext().setAuthentication(authentication);
		final UserDetails userDetails = jwtInMemoryUserDetailsService.loadUserByUsername(user.getUsername());
		final String token = jwtTokenUtil.generateToken(userDetails);
		return ResponseEntity.ok(new JwtResponse(token));
	}

	@PostMapping(value = "/profile", consumes = "application/json")
	public ResponseEntity<?> createProfile(@RequestBody String userProfile) throws Exception {

		logger.info("********createProfile() method invoked");
		List<ServiceInstance> instances = discoveryClient.getInstances(profileApplicationName);
		logger.info("********Profile Application Name instance size : " + instances.size());
		ServiceInstance serviceInstance = instances.get(0);
		String baseUrl = serviceInstance.getUri().toString();
		baseUrl = baseUrl + "/v1/profile";
		logger.info("********URL to hit Profile Micro Service : " + baseUrl);
		ResponseEntity<String> responseEntity = restTemplate.exchange(baseUrl, HttpMethod.POST,
				buildHttpEntityWithHeadersAndPayload(userProfile), String.class);
		if (responseEntity.getStatusCode().is2xxSuccessful()) {
			return ResponseEntity.ok(responseEntity.getBody());
		}
		return responseEntity;
	}

	private HttpEntity<String> buildHttpEntityWithHeadersAndPayload(String requestPayload) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(requestPayload, headers);
	}

	@DeleteMapping(value = "/profile/{username}")
	public ResponseEntity<?> deleteProfile(@PathVariable String username) throws JsonProcessingException {

		String deleteMessage = buildDeleteMessage(username);
		logger.info("**********Delete Message created for sending over KAFKA : " + deleteMessage);
		kafkaTemplate.send(requestTopicName, deleteMessage);
		return ResponseEntity.noContent().build();
	}

	public String buildDeleteMessage(String username) throws JsonProcessingException {
		UserProfileKafkaMessgae userProfileKafkaMsg = new UserProfileKafkaMessgae();
		userProfileKafkaMsg.setUsername(username);
		userProfileKafkaMsg.setOperation(OPERATION_DELETE);
		String deleteMessage = objectMapper.writeValueAsString(userProfileKafkaMsg);
		return deleteMessage;
	}

	@PutMapping(value = "/profile/{username}")
	public ResponseEntity<?> updateProfile(@PathVariable String username,
			@RequestBody UserProfileUpdate userProfileUpdate) throws JsonProcessingException {

		String updateMessage = buildUpdateMessage(username, userProfileUpdate);
		logger.info("**********Update Message created for sending over KAFKA : " + updateMessage);
		logger.info("**********Request Topic Name for sending over KAFKA : " + requestTopicName);
		kafkaTemplate.send(requestTopicName, updateMessage);
		return ResponseEntity.noContent().build();
	}

	public String buildUpdateMessage(String username, UserProfileUpdate userProfileUpdate)
			throws JsonProcessingException {
		UserProfileKafkaMessgae userProfileKafkaMsg = new UserProfileKafkaMessgae();
		userProfileKafkaMsg.setUsername(username);
		userProfileKafkaMsg.setOperation(OPERATION_UPDATE);
		userProfileKafkaMsg.setAddress(userProfileUpdate.getAddress());
		userProfileKafkaMsg.setPhoneNumber(userProfileUpdate.getPhoneNumber());
		String updateMessage = objectMapper.writeValueAsString(userProfileKafkaMsg);
		return updateMessage;
	}

}
