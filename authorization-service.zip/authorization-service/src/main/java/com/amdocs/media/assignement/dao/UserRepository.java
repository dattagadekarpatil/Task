package com.amdocs.media.assignement.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.amdocs.media.assignement.entity.User;

@Repository
public interface UserRepository extends CrudRepository<User, String>{

	public User findByUsername(String username);
}
