package com.amdocs.media.assignement.kafka.config;

import java.util.HashMap;
import java.util.Map;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

@Configuration
public class KafkaProducerConfig {

	@Value("${kafka.bootstrap.servers}")
	private String bootstrapServers;

	private static final Logger logger = LoggerFactory.getLogger(KafkaProducerConfig.class);

	@Bean
	public Map<String, Object> producerConfigs() {
		Map<String, Object> producerConfigMap = new HashMap<>();
		producerConfigMap.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
		producerConfigMap.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		producerConfigMap.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		logger.info("*************Producer configurations :  " + producerConfigMap);
		return producerConfigMap;
	}

	@Bean
	public ProducerFactory<String, String> producerFactory() {
		logger.info("***************Creating producerFactory.");
		return new DefaultKafkaProducerFactory<>(producerConfigs());
	}

	@Bean
	public KafkaTemplate<String, String> kafkaTemplate() {
		logger.info("***************Creating kafkaTemplate.");
		return new KafkaTemplate<>(producerFactory());
	}
}
