package com.amdocs.media.assignement.entity;

import java.io.Serializable;

public class UserProfileUpdate implements Serializable{

	private static final long serialVersionUID = 1L;
	private String address;
	private String phoneNumber;

	public UserProfileUpdate() {
	}

	public UserProfileUpdate(String address, String phoneNumber) {
		super();
		this.address = address;
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserProfileUpdate [address=");
		builder.append(address);
		builder.append(", phoneNumber=");
		builder.append(phoneNumber);
		builder.append("]");
		return builder.toString();
	}
}
