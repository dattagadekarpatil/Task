package com.amdocs.media.assignement.service;

import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.amdocs.media.assignement.dao.UserProfileRepository;
import com.amdocs.media.assignement.entity.UserProfile;
import com.amdocs.media.assignement.exception.UserProfileNotFoundException;
import com.amdocs.media.assignement.util.CommonResponse;

@Service
public class UserProfileServiceImpl implements UserProfileService {

	@Autowired
	UserProfileRepository userProfileRepository;

	private static final Logger logger = LoggerFactory.getLogger(UserProfileServiceImpl.class);

	@Override
	public CommonResponse<UserProfile> saveUserProfile(UserProfile userProfile) {
		CommonResponse<UserProfile> cr = new CommonResponse<>();
		try {
			logger.info("**********UserProfile saved/created in DB for username : " + userProfile.getUsername());
			UserProfile userProfiles = userProfileRepository.save(userProfile);
			if (userProfiles != null) {
				cr.setStatus("SUCCESS");
				cr.setReasonText("SUCCESSFULLY ADDED");
				cr.setResponseObject(userProfiles);
			} else {
				cr.setStatus("FAIL");
				cr.setReasonText("ADDED FAIL");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cr;
	}

	@Override
	public void updateUserProfile(UserProfile userProfile) {
		try {
			UserProfile userProfileDB = this.findUserProfileByUsername(userProfile.getUsername());
			if (userProfileDB != null) {
				userProfileDB.setAddress(userProfile.getAddress());
				userProfileDB.setPhoneNumber(userProfile.getPhoneNumber());
				userProfileRepository.save(userProfileDB);
				logger.info("**********UserProfile updated in DB for username : " + userProfile.getUsername());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteUserProfile(String username) {
		try {
			userProfileRepository.deleteById(username);
			logger.info("**********UserProfile deleted from DB for username : " + username);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public UserProfile findUserProfileByUsername(String username) throws UserProfileNotFoundException {

		Optional<UserProfile> userProfile = userProfileRepository.findById(username);
		if (userProfile.isPresent()) {
			return userProfile.get();
		}
		logger.info("**********UserProfile not found in DB for username : " + username);
		throw new UserProfileNotFoundException("User profile not found for username : " + username);
	}

}
