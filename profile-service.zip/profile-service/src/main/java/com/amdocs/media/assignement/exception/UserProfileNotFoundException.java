package com.amdocs.media.assignement.exception;

public class UserProfileNotFoundException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public UserProfileNotFoundException(String msg, Throwable t) {
		super(msg, t);
	}

	public UserProfileNotFoundException(String msg) {
		super(msg);
	}
}
