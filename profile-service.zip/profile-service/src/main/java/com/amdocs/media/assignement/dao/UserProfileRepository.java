package com.amdocs.media.assignement.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.amdocs.media.assignement.entity.UserProfile;

@Repository
public interface UserProfileRepository extends CrudRepository<UserProfile, String>{

}
