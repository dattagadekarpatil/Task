package com.amdocs.media.assignement.service;

import com.amdocs.media.assignement.entity.UserProfile;
import com.amdocs.media.assignement.util.CommonResponse;

public interface UserProfileService {

	public CommonResponse<UserProfile> saveUserProfile(UserProfile userProfile);
	public void updateUserProfile(UserProfile userProfile);
	public void deleteUserProfile(String username);
	public UserProfile findUserProfileByUsername(String username);
}
