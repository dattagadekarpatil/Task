package com.amdocs.media.assignement.util;

import java.io.Serializable;

public class CommonResponse<T> implements Serializable {

	private static final long serialVersionUID = 1L;
	private String status;
	private String reasonCode;
	private String reasonText;
	private transient T responseObject;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getReasonText() {
		return reasonText;
	}

	public void setReasonText(String reasonText) {
		this.reasonText = reasonText;
	}

	public T getResponseObject() {
		return responseObject;
	}

	public void setResponseObject(T responseObject) {
		this.responseObject = responseObject;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
