package com.amdocs.media.assignement.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.amdocs.media.assignement.entity.UserProfile;
import com.amdocs.media.assignement.service.UserProfileService;
import com.amdocs.media.assignement.util.CommonResponse;

@RestController
@RequestMapping("/v1")
@CrossOrigin("*")
public class UserProfileController {

	@Autowired
	UserProfileService userProfileService;

	private static final Logger logger = LoggerFactory.getLogger(UserProfileController.class);

	@PostMapping(value = "/profile", consumes = "application/json")
	public ResponseEntity<CommonResponse<UserProfile>> addUserProfile(@RequestBody UserProfile userProfile) {

		ResponseEntity<CommonResponse<UserProfile>> response = null;
		CommonResponse<UserProfile> cr = new CommonResponse<>();
		cr = userProfileService.saveUserProfile(userProfile);
		if (cr.getStatus().equalsIgnoreCase("success")) {
			response = new ResponseEntity<CommonResponse<UserProfile>>(cr, HttpStatus.OK);
			logger.info("***************User profile created with details : "
					+ response.getBody().getResponseObject().toString());
		} else {
			response = new ResponseEntity<CommonResponse<UserProfile>>(cr, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
}
