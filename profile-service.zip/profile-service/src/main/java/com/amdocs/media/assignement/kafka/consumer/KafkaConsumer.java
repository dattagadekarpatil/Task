package com.amdocs.media.assignement.kafka.consumer;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import com.amdocs.media.assignement.entity.UserProfile;
import com.amdocs.media.assignement.entity.UserProfileKafkaMessgae;
import com.amdocs.media.assignement.service.UserProfileService;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class KafkaConsumer {

	private final ObjectMapper objectMapper = new ObjectMapper();
	private static final String OPERATION_DELETE = "deleteProfile";
	private static final String OPERATION_UPDATE = "updateProfile";

	@Autowired
	UserProfileService userProfileService;

	private static final Logger logger = LoggerFactory.getLogger(KafkaConsumer.class);

	@KafkaListener(topics = "Profile-Updater-IN", containerFactory = "kafkaListenerContainerFactory")
	public void listen(String consumedMessage) {
		String username = null;
		if (!StringUtils.isEmpty(consumedMessage)) {
			UserProfileKafkaMessgae userProfileKafkaMsg;
			try {
				userProfileKafkaMsg = objectMapper.readValue(consumedMessage, UserProfileKafkaMessgae.class);
				username = userProfileKafkaMsg.getUsername();
				String operation = userProfileKafkaMsg.getOperation();
				if (!StringUtils.isEmpty(username) && !StringUtils.isEmpty(operation)) {
					if (OPERATION_UPDATE.equals(operation)) {
						userProfileService.updateUserProfile(new UserProfile(userProfileKafkaMsg.getUsername(),
								userProfileKafkaMsg.getAddress(), userProfileKafkaMsg.getPhoneNumber()));
						logger.info("************* User profile updated for username : " + username);
					} else if (OPERATION_DELETE.equals(operation)) {
						userProfileService.deleteUserProfile(username);
						logger.info("************* User profile deleted for username : " + username);
					}
				}
			} catch (Exception e) {
				logger.info(
						"************* Error Occured in Kafka Consumer while processing request message for username: "
								+ username);
				e.printStackTrace();
			}
		}
	}
}
