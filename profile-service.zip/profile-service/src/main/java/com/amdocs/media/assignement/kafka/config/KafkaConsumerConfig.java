package com.amdocs.media.assignement.kafka.config;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

@Configuration
public class KafkaConsumerConfig {

	@Value("${kafka.bootstrap.servers}")
	private String bootstrapServers;

	@Value("${kafka.consumer.request.topic.name}")
	private String requestTopicName;
	
	@Value("${kafka.consumer.group.id}")
	private String consumerGroupId;
	
	private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerConfig.class);

	@Bean
	public Map<String, Object> consumerConfigs() {
		Map<String, Object> consumerConfigMap = new HashMap<>();
		consumerConfigMap.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
		consumerConfigMap.put(ConsumerConfig.CLIENT_ID_CONFIG, UUID.randomUUID().toString());
		consumerConfigMap.put(ConsumerConfig.GROUP_ID_CONFIG, consumerGroupId);
		logger.info("**************** ConsumerConfig created...");
		return consumerConfigMap;
	}

	@Bean
	public ConsumerFactory<String, String> consumerFactory() {
		logger.info("**************** ConsumerFactory created...");
		return new DefaultKafkaConsumerFactory<>(consumerConfigs(), new StringDeserializer(), new StringDeserializer());
	}
	
	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory(){
		ConcurrentKafkaListenerContainerFactory<String,String> concurrentKafkaListenerContainerFactory = new ConcurrentKafkaListenerContainerFactory<>();
		concurrentKafkaListenerContainerFactory.setConsumerFactory(consumerFactory());
		logger.info("**************** ConcurrentKafkaListenerContainerFactory created...");
		return concurrentKafkaListenerContainerFactory;
	}

}
